CCDC Tools
==============

Scripts, applications and other tools written for CCDC practices and competition.

##Scoring Client/Server##
Very simple scoring server for use with a client written in python for doing a mock competition. The client checks to make sure certain services are running and scans the system for an ownership.txt file (similar to capture the flag). Points aren't tallied but uptime and ownership are displayed. 

The server must be run on a Windows machine because it's written in C#.

##Scripts##

* configure-iptables.sh
  * Sets up iptables with a sane set of firewall rules and makes them persistent.
* copy-keys.sh
  * Copies SSH keys to a list of hosts for easier access or setting up key only authentication.
* search-immutable.sh
  * Searches Linux/Unix machine for files that have been modified with chattr.
* setup-linux.sh
  * Basic Linux configuration script to check things like iptables configuration, number of users, running processes, etc.
* watch-bash
  * Modifies bash settings to dump command history much more often, appends the history to the file bash_config and continueously echoes that to the screen to monitor all commands being entered.
