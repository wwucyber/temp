#!/usr/bin/python3
import subprocess
import platform
import fnmatch
import os
import socket
import time
import argparse


class ScoringClient(object):

    def __init__(self, ipaddress, port, services, names):
        self.system = platform.system()
        # List OS
        print(self.system + ' system')
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.s.connect((ipaddress, port))
        self.checks = 0
        self.services = services
        self.names = names
        if names:
            self.dict = {}
            for service, name in zip(services, names):
                self.dict[service] = name

    def append_status(self, name, status):
        if self.names:
            self.status.append((self.dict[name], status))
        else:
            self.status.append((name, status))

    # Search linux system starting at specified root location for file matching
    # given pattern
    def search(self, root, pattern):
        print("Searching for ownership...")
        matches = []
        for root, dirs, files, in os.walk(root):
            for filename in fnmatch.filter(files, pattern):
                matches.append(os.path.join(root, filename))
        print("Ownership found!")
        return matches

    # Strip name from each ownership.txt file listed in matches
    # Return list of "owners"
    def get_owners(self, matches):
        owners = []
        for match in matches:
            file = open(match, 'r')
            owner = file.read().strip()
            file.close()
            if owner and not owner.isspace():
                owners.append(owner)
            if self.checks % 3 == 0:
                try:
                    print("Deleting " + match + "...")
                    os.remove(match)
                except Exception as e:
                    print("Couldn't delete " + match)
                    print(str(e))
        return owners

    # Check for ownership.txt files and for running services
    # Status list is packaged as tuples to send to the server
    def run_check(self):
        self.checks += 1
        self.status = []
        self.owners = []
        if self.system == 'Linux':
            services = list(self.services)
            print("Checking services...")
            output = str(subprocess.check_output(['ps', '-A']))
            for process in services:
                if process in output:
                    print(process + " is running!")
                    self.append_status(process, 'up')
                else:
                    print(process + " is down...")
                    self.append_status(process, 'down')
            print("Services found!")
            self.owners.extend(self.get_owners(self.search('/', 'ownership.txt')))
            return self.status, self.owners
        # Checks for running services on a windows machine
        elif self.system == 'Windows':
            import wmi
            services = list(self.services)
            found = []
            c = wmi.WMI()
            print("Checking services...")
            for process in c.Win32_Process():
                if process.Name in services:
                    print(process.Name + " is running!")
                    found.append(process.Name)
                    self.append_status(process.Name, 'up')
            for service in services:
                if service not in found:
                    self.append_status(service, 'down')
            print("Services found!")
            self.owners.extend(self.get_owners(self.search('C:\\', 'ownership.txt')))
            return self.status, self.owners

    def send(self, message):
        self.s.sendall(message)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-s', action='store', dest='server', help='Enter a server address', required=True)
    parser.add_argument('-p', action='store', dest='port', help='Enter a port number', type=int)
    parser.add_argument('-t', action='store', dest='wait_time', help='Length of time to wait between checks',
                        required=False, type=int)
    parser.add_argument('-services', action='store', dest='services',
                        help='List of services to check for e.g. notepad.exe notepad++.exe', required=True, nargs='+')
    parser.add_argument('-names', action='store', dest='names', nargs="+",
                        help='More readable names for the services. Must be a list of all services in order if included.')
    arguments = parser.parse_args()
    print(arguments.services)
    if not arguments.wait_time:
        arguments.wait_time = 180
    if not arguments.port:
        arguments.port = 3000
    client = ScoringClient(arguments.server, arguments.port, arguments.services, arguments.names)
    # Continuously loop, waiting the specified length of time between checks
    while True:
        check_status, check_owners = client.run_check()
        print(check_status)
        print(check_owners)
        client.send(str(check_status).encode() + str(check_owners).encode())
        time.sleep(arguments.wait_time)
