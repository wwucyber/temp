﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Threading;
using System.Net;

namespace Scoring
{
    class Server
    {
        public string logPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\ServerLogs\\" + DateTime.Now.ToString("yyyyMMdd_hhss");
        private TcpListener tcpListener;
        private Thread listenThread;
        private Action<string> printMethod;
        private Dictionary<string, string> status;
        private Dictionary<string, DateTime> times;
        public Boolean exit;


        // Constructs server object and adds a thread to listen for clients
        public Server(Action<string> printMethod)
        {
            this.printMethod = printMethod;
            this.tcpListener = new TcpListener(IPAddress.Any, 3000);
            this.listenThread = new Thread(new ThreadStart(ListenForClients));
            this.status = new Dictionary<string, string>();
            this.times = new Dictionary<string, DateTime>();
            ConfigureLogs();
        }

        // Starts the listener thread
        public void Start() 
        {
            this.printMethod("Server Started!");
            this.listenThread.Start();
        }

        // Returns status dictionary
        public Dictionary<string, string> GetStatus()
        {
            CheckTimes();
            return this.status;
        }

        // Returns time dictionary
        public Dictionary<string, DateTime> GetTimes()
        {
            return this.times;
        }

        // Sets any status that is more than 5 minutes old to empty
        private void CheckTimes() 
        {
            foreach(KeyValuePair<string, DateTime> item in this.times) {
                if ((DateTime.Now - item.Value).TotalMinutes >= 5.00){
                    this.status[item.Key] = "";
                }
            } 
        }

        // Listens for any connecting clients, adds them to the status dictionary and creates a new thread for communications
        private void ListenForClients()
        {
            this.tcpListener.Start();

            while (!this.exit)
            {
                // AcceptTcpClient is blocking, this will ensure the program exits when it's supposed to
                if (tcpListener.Pending())
                {
                    TcpClient client = this.tcpListener.AcceptTcpClient();

                    Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClientComm));
                    clientThread.Start(client);
                    this.printMethod("Client connected!");
                }
            }
        }

        // Processes messages from the clients
        private void HandleClientComm(object client)
        {
            TcpClient tcpClient = (TcpClient)client;
            NetworkStream clientStream = tcpClient.GetStream();
            IPEndPoint ipep = (IPEndPoint) tcpClient.Client.RemoteEndPoint;
            IPAddress ipa = ipep.Address;
            if (!this.status.ContainsKey(ipa.ToString()))
            {
                this.status.Add(ipa.ToString(), "");
            }
            byte[] message = new byte[4096];
            int bytesRead;

            while (!this.exit) {
                bytesRead = 0;

                try
                {
                    bytesRead = clientStream.Read(message, 0, 4096);
                }
                catch
                {
                    break;
                }

                if (bytesRead == 0)
                {
                    this.printMethod("Disconnected from client");
                    break;
                }

                ASCIIEncoding encoder = new ASCIIEncoding();
                HandleMessage(ipa.ToString(), encoder.GetString(message, 0, bytesRead));
            }
            tcpClient.Close();
        }

        // Updates the dictionary values based on client message
        private void HandleMessage(String ipaddress, String message)
        {
            this.status[ipaddress] = message;
            this.times[ipaddress] = DateTime.Now;
            AddLog(ipaddress, message);
        }

        // Creates a log directory if necessary and outputs the directory
        private void ConfigureLogs()
        {
            this.printMethod("Saving logs in " + logPath);
            if (!System.IO.Directory.Exists(logPath))
            {
                System.IO.Directory.CreateDirectory(logPath);
            }
        }

        // Appends message to a logfile with the filename set to the client ipaddress with a timestamp
        private void AddLog(string ipAddress, string message) {
            string filePath = logPath + "\\" + ipAddress + ".txt";
            if (System.IO.File.Exists(filePath))
            {
                using (StreamWriter sw = File.AppendText(filePath))
                {
                    sw.WriteLine(message + " " + DateTime.Now.ToString("HH:mm:ss tt"));
                }
            }
            else
            {
                using (StreamWriter sw = File.CreateText(filePath))
                {
                    sw.WriteLine(message + " " + DateTime.Now.ToString("HH:mm:ss tt"));
                }
            }
        }
    }
}
