﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Text.RegularExpressions;

namespace Scoring
{
    public partial class Form1 : Form
    {

        public bool stop = false;
        private Server scorer;


        public Form1()
        {
            InitializeComponent();
        }

        delegate void SetTextCallback(string text);


        // Appends text to smaller console safely from within threads
        public void SetText(string text)
        {
            if (this.console1.InvokeRequired)
            {
                SetTextCallback d = new SetTextCallback(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                console1.AppendText(text + Environment.NewLine);
                ScrollDown();
            }
        }

        // Scrolls view to bottom of textbox
        private void ScrollDown()
        {
            console1.SelectionStart = console1.Text.Length;
            console1.ScrollToCaret();
        }

        // Creates the server object and starts it
        public void StartServer()
        {
            this.scorer = new Server(SetText);
            scorer.Start();
        }

        // Enables timer that updates the status and starts server
        private void beginButton_Click(object sender, EventArgs e)
        {
            SetText("Starting server...");
            StartServer();
            updateTimer.Enabled = true;
        }

        // Sets addressLabel to the ip address of the machine
        private void Form1_Load(object sender, EventArgs e)
        {
            addressLabel.Text = Dns.GetHostEntry(Dns.GetHostName()).AddressList.FirstOrDefault(ip => ip.AddressFamily == AddressFamily.InterNetwork).ToString();
        }

        // Disables the timer and attempts to exit any server threads
        private void stopButton_Click(object sender, EventArgs e)
        {
            updateTimer.Enabled = false;
            this.scorer.exit = true;
        }

        // Attempts to exit any server threads before the window is closed
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (this.scorer != null)
            {
                this.scorer.exit = true;
            }
        }

        // Gets client information from the server class and updates the console
        private void UpdateStatus()
        {
            console.Text = "";
            string tuple = @"\((.*?)\)";
            string outer = @"\[(.*?)\]";
            Dictionary<string, string> status = this.scorer.GetStatus();
            Dictionary<string, DateTime> times = this.scorer.GetTimes();
            foreach (var entry in status)
            {
                console.AppendText(entry.Key + ": ");
                if (entry.Value == "")
                {
                    AppendText(console, "NO STATUS", Color.Red);
                    console.AppendText(Environment.NewLine);
                    if (times.ContainsKey(entry.Key))
                    {
                        console.AppendText("Last check run: " + times[entry.Key].ToString("T") + Environment.NewLine);
                    }
                }
                else
                {
                    MatchCollection chunks = Regex.Matches(entry.Value, outer);
                    if (chunks.Count == 2)
                    {
                        foreach (Match m in Regex.Matches(chunks[0].Value, tuple))
                        {
                            String message = m.Value.Substring(1, m.Value.Length - 2);
                            String[] words = message.Split(null);
                            if (words.Length == 2)
                            {
                                if (words[1].Equals("'up'"))
                                {
                                    AppendText(console, words[0].Substring(1, words[0].Length - 3) + " ", Color.Green);
                                }
                                else
                                {
                                    AppendText(console, words[0].Substring(1, words[0].Length - 3) + " ", Color.Red);
                                }
                            }
                        }
                        console.AppendText(Environment.NewLine);
                        if (chunks[1].Value.Equals("[]"))
                        {
                            AppendText(console, "You're alone!" + Environment.NewLine, Color.Green);
                        }
                        else
                        {
                            console.AppendText("Owners: ");
                            AppendText(console, chunks[1].Value.Substring(1, chunks[1].Value.Length - 2), Color.Red);
                            console.AppendText(Environment.NewLine);
                        }
                        if (times.ContainsKey(entry.Key))
                        {
                            console.AppendText("Last check run: " + times[entry.Key].ToString("T") + Environment.NewLine);
                        }
                    }
                }
                
            }
        }

        // Calls the update status function every timer interval
        private void updateTimer_Tick(object sender, EventArgs e)
        {
            UpdateStatus();
        }

        // Appends text to console with color
        private void AppendText(RichTextBox console, string text, Color color)
        {
            console.SelectionStart = console.TextLength;
            console.SelectionColor = color;
            console.SelectedText += text;
        }

        // Changes the font size
        private void fontSelector_ValueChanged(object sender, EventArgs e)
        {
            console.Font = new System.Drawing.Font("Microsoft Sans Serif", (float)fontSelector.Value);
            console.SelectAll();
            console.SelectionFont = new System.Drawing.Font("Microsoft Sans Serif", (float)fontSelector.Value);
        }
    }

}